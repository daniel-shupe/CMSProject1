<?php
/*
    tof/ability.php
    Daniel Shupe
    CSIS 410
    This page details the faith-based abilities in Trials of Faith.
*/
    require '../header.php';
    display_header("Trials of Faith - Abilities Overview","An overview of the abilities in the Trials of Faith roleplaying game.","../onp.css");
?>
<?php
    require '../footer.php';
    require '../menu.php';
    require '../variables.php';
    display_menu($site_nav, $dropdown_nav, "menu");
?>
<div class="article">
<h1>Trials of Faith Roleplaying Game Abilities Overiew</h1>
<p>
    In Trials of Faith, adventurers have many different abilities at thier disposal.  The greatest of these abilities are called Miracles.
    Miracles become available once a player reaches the first level threshhold (by default, 100 faith points).  Miracles are cast using a 
    resource called Divine Favor.  This resource is shared by the group, and is capped out at 3.  Divine Favor is awarded to the players by
    the Game Master when accomplish a great feat.  Miracles have 3 levels which become unlocked as the player gains more faith.  Each class
    has their own Miracle that they can perform.  The Paladin Miracle, Divine Veil, is listed below.
</p><br />
<div class="class_name">Paladin Miracle - Divine Veil</div><br />
<p>
    1st Tier: The Paladin grants temporary hit points equal to twice his/her level to all allies within 60 yards.
</p>
<p>
    2nd Tier: In addition to its other effects, Divine Veil now grants a +2 bonus to armor class for all allies within 60 yards for 5 rounds.
</p>
<p>
    3rd Tier: In addition to its other effects, Divine Veil empowers the Paladin's shield, allowing the next Shield Block to prevent all damage.
    The shield does not take any damage from this.
</div>
<div class="footer">
<?php
    display_footer("../tof/ability.php");
?>
</div>
</body>
</html>